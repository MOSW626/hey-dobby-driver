This a directory for training images and labels.
