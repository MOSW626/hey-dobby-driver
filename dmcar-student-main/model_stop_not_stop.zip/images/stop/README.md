This is a directory for stop images.
