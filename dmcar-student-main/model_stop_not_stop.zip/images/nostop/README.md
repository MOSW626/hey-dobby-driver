This is a directory for no stop images.
